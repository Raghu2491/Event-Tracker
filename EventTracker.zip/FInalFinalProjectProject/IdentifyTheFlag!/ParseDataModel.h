//
//  ParseDataModel.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParseDataModel : NSObject
@property (strong,nonatomic) NSArray* ParseArray,*GeoPointsRadii; // fill this with retreived parse objects - precisely objectIDs
@property (strong,nonatomic) NSMutableArray* EventNames,*CatArray;
@property (strong,nonatomic) NSMutableArray* modEventNames;
@property (strong,nonatomic) NSMutableArray* EventLocations,*GeoPointsArray;
@property (strong,nonatomic) NSMutableArray* Images,*CatImages;

-(void) collectCityP:(NSString*) CityName;
@property NSString* CityNameP;

-(void) GetParseData;
-(void) CalRadius:(int) ft;
-(void) GetCats;
//-(NSArray*) GetParseData;

-(NSString*)RetrieveUserAddress;

@end
