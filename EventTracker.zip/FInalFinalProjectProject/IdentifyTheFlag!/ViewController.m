//
//  ViewController.m
//  IdentifyTheFlag!
//  Created by Apuroopa Katralapalli on 9/29/15.
//  Copyright (c) 2015 Apuroopa Katralapalli All rights reserved.
//


#import "ViewController.h"
@import CoreLocation;
#import <AddressBook/AddressBook.h>
#import "RegisterViewController.h"
#import <Parse/Parse.h>
@interface ViewController ()





@end

@implementation ViewController



- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.Latitude = 0;
    self.Longitude = 0;
    NSLog(@"locationManager:didUpdateLocations:");
   
}


- (void)locationManager: (CLLocationManager *)manager didUpdateLocations: (NSArray *)locations
{

    CLLocation* locn = [locations lastObject];
    _Latitude = locn.coordinate.latitude;
    _Longitude = locn.coordinate.longitude;
    
    self.UserLocation =CLLocationCoordinate2DMake(_Latitude,_Longitude);
    NSLog(@"Latitude:  %f,Longitude: %f",_Latitude,_Longitude);
    [self ReverseGeoCode];
    
    
    [self performSegueWithIdentifier:@"startApp" sender:self];
    }




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



///////////

-(void) ReverseGeoCode
{
    CLLocation *newLocation = [[CLLocation alloc]initWithLatitude:_Latitude longitude:_Longitude];
    
    CLGeocoder *geoCoder = [[CLGeocoder alloc]init];
         [geoCoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *placemarks, NSError * error)
    {
        if(error)
        {
            NSLog(@"Reverse GeoCoding failed with error %@ ",error);
            return;
        }
    
    if(placemarks.count>0)
    
    {
        
        CLPlacemark *placemark = placemarks[0];
   // NSLog(@" PlaceMarks is: %@", [placemarks objectAtIndex:0]);
        
    NSDictionary *AddressDictionary =placemark.addressDictionary;
        NSString* Street = [AddressDictionary objectForKey:(NSString* ) kABPersonAddressStreetKey];
       
        _City=[AddressDictionary objectForKey:(NSString* ) kABPersonAddressCityKey];
       
        NSString* State = [AddressDictionary objectForKey:(NSString* ) kABPersonAddressStateKey];
        
        NSString* Country = [AddressDictionary objectForKey:(NSString* ) kABPersonAddressCountryKey];
       
        NSString* Zip = [AddressDictionary objectForKey:(NSString* ) kABPersonAddressZIPKey];
       
        NSString *fromAddressString=[NSString stringWithFormat:@"%@ %@ %@ %@ %@", Street, _City, State, Country, Zip];
       
        
        
   [self captureObj:fromAddressString];

        /// capture city value for RegisterViewController
        
        RegisterViewController *obj = [[RegisterViewController alloc]init];
        
        [obj collectCity:_City];
        
   // NSLog(@" City is: %@", _City);
}
    
    }];
    
}
/////////

-(void) captureObj:(NSString*)ID
{
    PFObject *  push;

    push = [PFObject objectWithClassName:@"UserLocation"];
    push[@"UserAdress"] =ID;
    push[@"dupID"] = @"Yes";
    [push saveInBackground];
}
@end
