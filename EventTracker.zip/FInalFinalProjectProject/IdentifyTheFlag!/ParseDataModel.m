//
//  ParseDataModel.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "ParseDataModel.h"
#import <Parse/Parse.h>
#import "ViewController.h"

@implementation ParseDataModel

-(void) GetCats
{
    /*
    self.CatArray =[[NSMutableArray alloc]init];
    self.CatImages =[[NSMutableArray alloc]init];
    
    PFQuery *RetreiveQuery = [PFQuery queryWithClassName:@"Categories"];
   NSArray *CatsArray = [[NSArray alloc]initWithArray:[RetreiveQuery findObjects]];
    for(int i=0; i< [ CatsArray count] ; i++)
    {
        
        PFObject *tempObj = [CatsArray objectAtIndex:i];
        self.CatArray[i]=tempObj[@"CategoryName"];
        NSLog(@" %%%%%%%%%%%%%%%%%%%%%% CatArray %@", self.CatArray);
        
        
        PFFile *imageFile = tempObj[@"CategoryImage"];
        //NSLog(@"*****See here tempObj[@\"imageFile\"] ************  %@",tempObj[@"Images"]);
        
        UIImage *img= [UIImage imageWithData:[imageFile getData]];
        self.CatImages[i] = img;
    }*/

}
-(void) GetParseData
{
      PFQuery *RetreiveQuery = [PFQuery queryWithClassName:@"GCD"];
    
    self.ParseArray = [RetreiveQuery findObjects];
    
    
    //---<fill EventNames by retreiving from parse> working--------------
    
   // NSLog(@"findObjects %lu" ,self.ParseArray.count);
    self.EventNames = [[NSMutableArray alloc] init];
    self.Images= [[NSMutableArray alloc] init];
    for(int i=0; i< [ self.ParseArray count] ; i++)
    {
        
        PFObject *tempObj = [self.ParseArray objectAtIndex:i];
        self.EventNames[i]=tempObj[@"EventName"];
    
        PFFile *imageFile = tempObj[@"Images"];
        //NSLog(@"*****See here tempObj[@\"imageFile\"] ************  %@",tempObj[@"Images"]);
        
         UIImage *img= [UIImage imageWithData:[imageFile getData]];
        self.Images[i] = img;
       // NSLog(@"[imageFile getData] %@", img);
        
        /*[imageFile getDataInBackgroundWithBlock:^(NSData *data,NSError *error)
         {
               if(!error)
             {
                 UIImage *img = [UIImage imageWithData:data];
                 self.Images[i] = img;
                 //NSLog(@"*****See here count ************ self.Images[i]: %@",self.Images[i]);
                 // NSLog(@"Is of type UIImage?: %@", ([self.Images[i] isMemberOfClass:[UIImage class]])? @"Yes" : @"No");
             }
             [self FillparseData:self.Images];
             //NSLog(@" FillparseData Images count %lu",self.Images.count);

         }];*/
     
       // NSLog(@"Is of type UIImage?: %@", ([self.Images[0] isMemberOfClass:[UIImage class]])? @"Yes" : @"No");
        
    }
    
   // NSLog(@"EventNames count %lu",self.EventNames.count);
    NSLog(@"Images count %lu",self.Images.count);
    
   // NSLog(@" ParseDataModel City is: %@", vm.City);
 
}

-(NSString*)RetrieveUserAddress
{
    NSString *addrs;
    PFQuery *RetreiveQuery = [PFQuery queryWithClassName:@"UserLocation"];
    
    NSArray *AddrssArray = [[NSArray alloc]initWithArray:[RetreiveQuery findObjects]] ;
    
    for(int i=0; i< [ AddrssArray count] ; i++)
    {
       
        PFObject *tempObj = [AddrssArray objectAtIndex:i];
        
        if([tempObj[@"dupID"] isEqualToString:@"Yes"] )
        {
            addrs = tempObj[@"UserAdress"];
              tempObj[@"dupID"] = @"No";
            [tempObj saveInBackground];
        }
    }
    
    return addrs;

}


-(void) collectCityP:(NSString*) CityName;
{
    _CityNameP = CityName;
    //  NSLog(@" RegisterViewController  City is: %@", _CityName);
    
}


-(void) CalRadius:(int) rad


{
    
    CLLocation *Userlocation = [[CLLocation alloc] initWithLatitude:57.052443 longitude:9.910623];
    
    PFGeoPoint *ULocation =  [[PFGeoPoint alloc]init];
    ULocation.latitude=57.052443;
    ULocation.longitude=9.910623;
    
    // PFGeoPoint *ULocation =[PFGeoPoint geoPointWithLatitude:40.75060000 longitude:73.99360000];
    
    self.GeoPointsRadii = [[NSMutableArray alloc] init];
    self.modEventNames =  [[NSMutableArray alloc] init];
    
    //  --------<filtering radius array >---------
    
    PFQuery *query = [PFQuery queryWithClassName:@"GCD"];
    [query whereKey:@"EventLocation" nearGeoPoint:ULocation withinKilometers:rad];
    self.GeoPointsRadii = [[NSArray alloc] initWithArray:[query findObjects]];
    
   NSLog(@"Displaying PARSE HERE GeoPointsRadii %@ \n",  self.GeoPointsRadii);
    
    for(int i=0; i< [ self.GeoPointsRadii  count] ; i++)
    {
        
        //  PFObject *tempObj = [self.ParseArray objectAtIndex:i];
        PFObject *tempObj = self.GeoPointsRadii [i];
        self.modEventNames[i]=tempObj[@"EventName"];
        
       // NSLog(@" mod events array in cal rad method: %lu",self.modEventNames.count);
        // self.EventNames[i]=tempObj[@"EventName"];
    }
    
   // NSLog(@"counting GeoPointsRadii %lu \n",  self.modEventNames.count);
    
    //-< calculating distance array> working--------
    
    // [array addObject:[NSNumber numberWithFloat:1.0f]];
   /*
    for(int i =0; i <self.GeoPointsArray.count;i++)
    {
        float ft = [Userlocation distanceFromLocation:self.GeoPointsArray[i]];
        // NSLog(@"***Getting  HERE distance in km %f \n",  ft);
        [self.GeoPointsRadii insertObject:[NSNumber numberWithFloat:ft/1000]atIndex:i];
    }
    //   NSLog(@"***Getting  HERE  distance in km %@ \n",  self.GeoPointsRadii);
    */
}


@end
