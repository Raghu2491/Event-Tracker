//
//  TrendingTableViewController.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "TrendingTableViewController.h"
#import "ParseDataModel.h"
#import "TrendingEventViewController.h"

#import <Parse/Parse.h>
// REUSE CELL IDENTIFIER TrendingCell
@interface TrendingTableViewController ()

@end

@implementation TrendingTableViewController

- (void)viewDidLoad {
           [super viewDidLoad];
        //NSLog(@" *******VIEW DID LOAD*********");
        
        self.TrendingTableView.delegate = self;
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"reloadData" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadTable:) name:@"reloadData" object:nil];
        
        _TrendingDataArray = [[NSMutableArray alloc]init];
        _TrendingImageArray = [[NSMutableArray alloc]init];
        
        ParseDataModel *obj = [[ParseDataModel alloc]init];
        [obj GetParseData];
        
        _TrendingDataArray = obj.EventNames;
        _TrendingImageArray =obj.Images;
        
}



- (void)reloadTable:(NSNotification *)notif
{
    ParseDataModel *pmg = [[ParseDataModel alloc]init];
    [pmg CalRadius:6000];
    // NSLog(@"radius chosen %d", _rad);
    _TrendingDataArray = pmg.modEventNames;
    [self.TrendingTableView reloadData];
}

-(void) collectRadius:(int) rad
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadData" object:self];

}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSLog(@" RELOADING RELOADING");
    
        
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   // NSLog(@"numberOfRowsInSection called");
    
        return self.TrendingDataArray.count;
   
    
    }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSLog(@"TABLE VIEW method called");
    
    static NSString *CellIdentifier = @"TrendingCell"; // reuse identifier
    
    // check if we can reuse a cell from row that just went off screen
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
         [cell setBackgroundColor:[UIColor lightGrayColor]];
    // create new cell, if needed
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
         //NSLog(@"[_TrendingImageArray objectAtIndex:indexPath.row] %lu " ,_TrendingImageArray.count);
   
     UIImage *image= [_TrendingImageArray objectAtIndex:indexPath.row];
     cell.imageView.image= image;  ///EXCEPTION
    
    cell.textLabel.text = [_TrendingDataArray objectAtIndex:indexPath.row];
       // set accessory type to standard detail disclosure indicator
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}


- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // note which segue chosen (need to know if more than one segue from current view controller)
    NSLog( @"Transition via segue: '%@'", segue.identifier);
    
    [super prepareForSegue:segue sender:sender];
    
    // pick up destination view controller from segue object

    TrendingEventViewController *dvc = segue.destinationViewController;
    ViewController *obj = [[ViewController alloc]init];
   // NSLog(@"UserLocation %@", obj.UserLocation);
    dvc.fromLatitude =obj.UserLocation.latitude;
    dvc.fromLongitude = obj.UserLocation.longitude;
    NSIndexPath *path = self.tableView.indexPathForSelectedRow;
   dvc.Eventname = [self.TrendingDataArray objectAtIndex:path.row];
    dvc.image=[self.TrendingImageArray objectAtIndex:path.row];
    ParseDataModel *pobj = [[ParseDataModel alloc]init];
    [pobj GetParseData];
    
    for(int i=0; i< [ pobj.ParseArray count] ; i++)
    {
        
        PFObject *tempObj = [pobj.ParseArray objectAtIndex:i];
        if([[self.TrendingDataArray objectAtIndex:path.row] isEqualToString:tempObj[@"EventName"] ])
        {
            PFGeoPoint *temp = [[PFGeoPoint alloc]init];
            temp= tempObj[@"EventLocation"];
            dvc.About = tempObj[@"Description"];
            NSLog(@"Description %@",dvc.About);
            dvc.toLatitude=temp.latitude;
            dvc.toLongitude=temp.longitude;
            NSLog(@"segue toLocation %f, %f", temp.latitude,temp.longitude);
            PFObject *object = [PFObject objectWithoutDataWithClassName:@"UserLocation" objectId:tempObj.objectId]; [object deleteEventually];

            dvc.paidUnpaid = (BOOL)tempObj[@"Paid"];
        }

    }
    
    dvc.fromAddress = [pobj RetrieveUserAddress];

   // dvc.paidUnpaid

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end



















