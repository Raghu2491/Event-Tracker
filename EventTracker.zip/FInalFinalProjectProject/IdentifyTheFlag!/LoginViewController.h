//
//  LoginViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *loginUsernameField;

@property (weak, nonatomic) IBOutlet UITextField *loginPasswordFields;


- (IBAction)loginButton:(id)sender;

@end
