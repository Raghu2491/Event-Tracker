//
//  PayPalWebPageViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/9/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PayPalWebPageViewController : UIViewController <UITextFieldDelegate,UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *payPalWebPage;
@property (weak, nonatomic) IBOutlet UIToolbar *toolBar;
@property (weak, nonatomic) IBOutlet UITextField *addr;

- (IBAction)backButton:(id)sender;









@end
