//
//  ViewController.h
//  IdentifyTheFlag!
//  Created by Apuroopa Katralapalli on 9/29/15.
//  Copyright (c) 2015 Apuroopa Katralapalli. All rights reserved.
//

@import UIKit;
@import CoreLocation;

@interface ViewController : UIViewController <CLLocationManagerDelegate>

@property float Latitude; // latitude value of ur current location
@property float Longitude; //  longitude value of ur current location

@property NSString* City;
@property CLLocationCoordinate2D UserLocation;
-(void) captureObj:(NSString*) ID;
@property NSString* UserID;
@end