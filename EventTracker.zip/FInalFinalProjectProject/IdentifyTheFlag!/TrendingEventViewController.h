//
//  TrendingEventViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/9/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import <Parse/Parse.h>

@interface TrendingEventViewController : UIViewController

@property NSString *Eventname;

- (IBAction)goingButton:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *notGoingButton;

@property (weak, nonatomic) IBOutlet UILabel *paidUnpaidLabel;

@property Boolean paidUnpaid;


@property (weak, nonatomic) IBOutlet UILabel *EventNamLabel;

@property float fromLatitude;
@property float fromLongitude;
@property float toLatitude;
@property float toLongitude;

@property (strong, nonatomic) CLLocation *fromLocation;
@property (strong, nonatomic) CLLocation *toLocation;

- (IBAction)directionsButton:(id)sender;
-(void) ReverseGeocode ;

-(void) capturetoAddrs;
@property (strong, nonatomic) NSString *fromAddress;
@property (strong, nonatomic) NSString *toAddress;

@property  NSString *About;
@property (strong, nonatomic)  UIImage *image;

@property (weak, nonatomic) IBOutlet UIImageView *EventImageView;
@property (weak, nonatomic) IBOutlet UITextView *AboutField;




@end
