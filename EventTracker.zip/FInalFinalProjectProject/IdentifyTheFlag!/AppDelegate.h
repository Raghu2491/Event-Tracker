//
//  AppDelegate.h
//  IdentifyTheFlag!
//  Created by Apuroopa Katralapalli  on 9/29/15.
//  Copyright (c) 2015 Apuroopa Katralapalli. All rights reserved.
//


@import UIKit;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


