//
//  SelectRadiusViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectRadiusViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIPickerView *RadiusPicker;
@property (weak, nonatomic) IBOutlet UILabel *RadiusChosen;
@end
