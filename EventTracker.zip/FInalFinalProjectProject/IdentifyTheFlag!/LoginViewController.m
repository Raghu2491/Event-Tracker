//
//  LoginViewController.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "LoginViewController.h"
#import <Parse/Parse.h>

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.loginUsernameField.delegate = (id)self;
    self.loginPasswordFields.delegate=(id)self;
self.view.backgroundColor = [UIColor grayColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [textField setText:@""];
    textField.layer.borderWidth=.5f;
    textField.layer.borderColor=[[UIColor blackColor]CGColor];
    return YES;
}

- (IBAction)loginButton:(id)sender {
    NSLog(@"Login userbut");
    
    [PFUser logInWithUsernameInBackground:_loginUsernameField.text password:_loginPasswordFields.text block:^
     (PFUser *  user, NSError *  error) {
         if(!error)
         {
             NSLog(@"Login user");
             
             [self performSegueWithIdentifier:@"alreadyReg" sender:self];
         }
         else
         {
             NSLog(@"%@",error);
             
             self.loginUsernameField.layer.borderWidth=.5f;
             self.loginUsernameField.layer.borderColor=[[UIColor redColor]CGColor];
             self.loginUsernameField.text =@"Invalid credentials";
             
             self.loginPasswordFields.layer.borderWidth=.5f;
             self.loginPasswordFields.layer.borderColor=[[UIColor redColor]CGColor];
             self.loginPasswordFields.text =@"Invalid credentials";

         }
     }];
    
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
