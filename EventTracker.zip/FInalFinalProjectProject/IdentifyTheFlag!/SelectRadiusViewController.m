//
//  SelectRadiusViewController.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "SelectRadiusViewController.h"
#import "TrendingTableViewController.h"
@interface SelectRadiusViewController ()
{
    NSArray *Radii ,*Data;
}
@end

@implementation SelectRadiusViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];

    self.RadiusPicker.delegate=self;
    Radii=[[NSArray alloc]initWithObjects:[NSNumber numberWithInt:5],[NSNumber numberWithInt:10],[NSNumber numberWithInt:15],[NSNumber numberWithInt:20], nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return Radii.count;
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
    
    return [Radii[row] stringValue];
    
    
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
    NSString *result = [NSString stringWithFormat:@"Radius Chosen is %@", Radii[row]];
    
     self.RadiusChosen.text=result;
    
    TrendingTableViewController *tobj = [[TrendingTableViewController alloc]init];
    
    [tobj collectRadius:[Radii[row] intValue]];
    

    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
