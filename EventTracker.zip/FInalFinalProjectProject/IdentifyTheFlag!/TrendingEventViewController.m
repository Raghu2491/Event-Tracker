//
//  TrendingEventViewController.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/9/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "TrendingEventViewController.h"
#import "ViewController.h"
#import<CoreLocation/CoreLocation.h>
#import<MapKit/MapKit.h>
#import <AddressBook/AddressBook.h>
#import<Parse/Parse.h>

@interface TrendingEventViewController ()
{
    
NSString *fromAddress ;

}
@end

@implementation TrendingEventViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];

    if(self.paidUnpaid)
        self.paidUnpaidLabel.text = @"Paid";
    else
        self.paidUnpaidLabel.text = @"UnPaid";

    self.EventImageView.image=self.image;
    self.AboutField.text = self.About;
   
    NSLog(@"  self.About %@", self.About);
    
    //NSLog(@"  toLocation   EventLocation %f, %f", self.toLatitude, self.toLongitude);
    
    _toLocation = [[CLLocation alloc]initWithLatitude:_toLatitude longitude:_toLongitude];

    
    NSLog(@"Address %@", _fromAddress);
    NSLog(@"toLocation %@", _toLocation);

    
    
    self.EventNamLabel.text=self.Eventname;
    [self ReverseGeocode];
    
        
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)RetrieveEventAddress
{
    PFQuery *RetreiveQuery = [PFQuery queryWithClassName:@"EventLocation"];
    
    NSArray *AddrssArray = [[NSArray alloc]initWithArray:[RetreiveQuery findObjects]] ;
    
    for(int i=0; i< [ AddrssArray count] ; i++)
    {
        
        PFObject *tempObj = [AddrssArray objectAtIndex:i];
        
        if([tempObj[@"EveID"] isEqualToString:@"Yes"] )
        {
            PFObject *object = [PFObject objectWithoutDataWithClassName:@"EventLocation" objectId:tempObj.objectId]; [object deleteEventually];
            
            _toAddress = tempObj[@"EventAdress"];
            NSLog(@"retreive to address %@",_toAddress);
            tempObj[@"EveID"] = @"No";
            [tempObj saveInBackground];
        }
       

    }
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goingButton:(id)sender
{
    //payPal
    if(self.paidUnpaid)
    [self performSegueWithIdentifier:@"payPal" sender:self];
}


- (IBAction)directionsButton:(id)sender
{
    [self RetrieveEventAddress];

    NSLog(@"directionsButton _toAddress %@",_toAddress);
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
    
    [geocoder geocodeAddressString:_fromAddress
                 completionHandler:^(NSArray *placemarks,NSError *error){
                     CLPlacemark *geocodedFromPlacemark=[placemarks objectAtIndex:0];
                     MKPlacemark *fromPlacemark=[[MKPlacemark alloc]
                                                 initWithCoordinate:geocodedFromPlacemark.location.coordinate addressDictionary:
                                                 geocodedFromPlacemark.addressDictionary];
                     
                     MKMapItem *fromMapItem=[[MKMapItem alloc]initWithPlacemark:fromPlacemark];
                     [fromMapItem setName:geocodedFromPlacemark.name];
                     
                     [geocoder geocodeAddressString:_toAddress
                                  completionHandler:^(NSArray *placemarks, NSError *error){
                                      CLPlacemark *geocodedToPlacemark=[placemarks objectAtIndex:0];
                                      MKPlacemark *toPlacemark=[[MKPlacemark alloc]initWithCoordinate:geocodedToPlacemark.location.coordinate
                                                                                    addressDictionary:geocodedToPlacemark.addressDictionary];
                                      
                                      MKMapItem *toMapItem=[[MKMapItem alloc] initWithPlacemark:toPlacemark];
                                      [toMapItem setName:geocodedToPlacemark.name];
                                      
                                      NSDictionary *launchOpitons=
                                      @{MKLaunchOptionsDirectionsModeKey:
                                            MKLaunchOptionsDirectionsModeDriving};
                                      
                                      [MKMapItem openMapsWithItems:@[fromMapItem,toMapItem] launchOptions:launchOpitons];
                                      
                                  }];
                     
                 }];

    ///////////////
   
        
}



-(void) captureFromAddrs : (NSString *) toAddrs
{
    NSLog(@" capture toAddress %@", toAddrs);


    PFObject *  push;
    
    push = [PFObject objectWithClassName:@"EventLocation"];
    push[@"EventAdress"] =toAddrs;
    push[@"EveID"] = @"Yes";
    [push saveInBackground];
}


//next write a function to retreive to adress where EVEID is yes and pass it to map directions
-(void) ReverseGeocode
{
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
    
    [geocoder reverseGeocodeLocation:self.toLocation
                   completionHandler:^(NSArray *placemarks, NSError *error){
                       if(error){
                           NSLog(@"Geocode failed with error: %@",error);
                           return;
                       }
                       if(placemarks &&placemarks.count>0){
                           CLPlacemark *placemark=placemarks[0];
                           NSDictionary *addressDictionary=placemark.addressDictionary;
                           NSString *Address=[addressDictionary objectForKey:(NSString*)
                                              kABPersonAddressStreetKey];
                           NSString *City=[addressDictionary objectForKey:(NSString*)
                                           kABPersonAddressCityKey];
                           NSString *State=[addressDictionary objectForKey:(NSString*)
                                            kABPersonAddressStateKey];
                            NSString* Country = [addressDictionary objectForKey:(NSString* ) kABPersonAddressCountryKey];
                           NSString *Zip=[addressDictionary objectForKey:(NSString*)
                                          kABPersonAddressZIPKey];
                           NSString *adress=[NSString localizedStringWithFormat:@"%@ %@ %@ %@ %@",
                                             Address,City,State,Country,Zip];
                           NSLog(@" ReverseGeocode toAddress %@", adress);
                           [self captureFromAddrs : adress];
                       }
                       
                   }];
}

@end
































