//
//  TrendingTableViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TrendingTableViewController : UITableViewController <UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>

@property (strong, nonatomic) NSMutableArray *TrendingDataArray, *MDArray;
@property (strong, nonatomic) NSMutableArray *TrendingImageArray, *MIArray;

@property (strong, nonatomic) IBOutlet UITableView *TrendingTableView;
@property int rad;

-(void) collectRadius:(int) rad;

@end
