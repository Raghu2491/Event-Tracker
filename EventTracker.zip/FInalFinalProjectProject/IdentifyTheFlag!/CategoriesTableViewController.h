//
//  CategoriesTableViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/10/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoriesTableViewController : UITableViewController  <UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>

@property (strong, nonatomic) NSMutableArray *CatDataArray;
@property (strong, nonatomic) NSMutableArray *CatImageArray;

@property (strong, nonatomic) IBOutlet UITableView *CatTableView;

@end
