//
//  PayPalWebPageViewController.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/9/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "PayPalWebPageViewController.h"

@interface PayPalWebPageViewController ()

@end

@implementation PayPalWebPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // allow gestures to change scale
    self.payPalWebPage.scalesPageToFit = YES;
    // set up web view delegate
    self.payPalWebPage.delegate = self;
    
    NSString *fullURL = @"https://www.paypal.com/home";
    NSURL *url = [NSURL URLWithString:fullURL];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [_payPalWebPage loadRequest:requestObj];

}

- (IBAction)backButton:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) webViewDidFinishLoad:(UIWebView *)webView
{
    // update address area of tool bar
    self.addr.text = webView.request.URL.resourceSpecifier;
    // show raw content of web view in text view
    //    self.feed.text = [NSString stringWithContentsOfURL: webView.request.URL
    //                                              encoding: NSUTF8StringEncoding
    //                                                 error: NULL];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/






















@end
