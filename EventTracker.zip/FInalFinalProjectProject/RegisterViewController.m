//
//  RegisterViewController.m
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import "RegisterViewController.h"
#import <Parse/Parse.h>

@interface RegisterViewController ()

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor grayColor];

     
}
-(void) collectCity:(NSString*) CityName
{
    _CityName = CityName;
    NSLog(@" RegisterViewController  City is: %@", _CityName);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)registeredButton:(id)sender {
    
    // [UIView animateWithDuration:0.3 animations:^{
    //   _loginOverlayView.frame = self.view.frame;
    
    //}];
   // NSLog(@" already registered button method");
    // NSLog(@" RegisterViewController  City is: %@", _CityName);
    [self performSegueWithIdentifier:@"login" sender:self];
}

- (IBAction)registerAction:(id)sender
{
    // when you hit register button dismiss the keyboard
    
    [_usernameField resignFirstResponder];
    [_emailField resignFirstResponder];
    [_passwordField resignFirstResponder];
    [_reEnterPasswordField resignFirstResponder];
    
    // check all the fields on the Rgister view are filled before register action
    self.usernameField.delegate = self;
    self.emailField.delegate=self;
    self.passwordField.delegate=self;
    self.reEnterPasswordField.delegate=self;
    
    [self checkFieldsComplete];
    
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [textField setText:@""];
    textField.layer.borderWidth=.5f;
    textField.layer.borderColor=[[UIColor blackColor]CGColor];
    return YES;
}


-(void) checkFieldsComplete
{
    // check all the fields on the Rgister view are filled before register action and passwords match
    NSLog(@" username %@", _usernameField.text );
    
    if([_usernameField.text isEqualToString:@""] || [_emailField.text isEqualToString:@""] || [_passwordField.text isEqualToString:@""] || [_reEnterPasswordField.text isEqualToString:@""] )
    {
        if([_usernameField.text isEqualToString:@""] )
        {
        _usernameField.layer.borderWidth=.5f;
        _usernameField.layer.borderColor=[[UIColor redColor]CGColor];
            _usernameField.text =@"Fill the required fields";

        }
        
        if([_emailField.text isEqualToString:@""] )
        {
            _emailField.layer.borderWidth=.5f;
            _emailField.layer.borderColor=[[UIColor redColor]CGColor];
            _emailField.text =@"Fill the required fields";

        }
        
        if([_passwordField.text isEqualToString:@""] )
        {
            _passwordField.layer.borderWidth=.5f;
            _passwordField.layer.borderColor=[[UIColor redColor]CGColor];
            _passwordField.text =@"Fill the required fields";

        }
        if([_reEnterPasswordField.text isEqualToString:@""] )
        {
            _reEnterPasswordField.layer.borderWidth=.5f;
            _reEnterPasswordField.layer.borderColor=[[UIColor redColor]CGColor];
            _reEnterPasswordField.text =@"Fill the required fields";

        }
        
        
       
    }
    else
    {
        NSLog(@"Passwords match");
        [self checkPasswordsMatch];
    }
}


-(void) checkPasswordsMatch
{
    if(_passwordField.text!=_reEnterPasswordField.text)
    {
        _passwordField.layer.borderWidth=.5f;
        _passwordField.layer.borderColor=[[UIColor redColor]CGColor];
        _passwordField.text =@"Passwords do not match";
        
        
        _reEnterPasswordField.layer.borderWidth=.5f;
        _reEnterPasswordField.layer.borderColor=[[UIColor redColor]CGColor];
        _reEnterPasswordField.text =@"Passwords do not match";

    }
    else
        [self registerNewUser];
}


-(void) registerNewUser

{
    PFUser *newUser = [PFUser user];
    newUser.username=_usernameField.text;
    newUser.email=_emailField.text;
    newUser.password=_passwordField.text;
    
    [newUser signUpInBackgroundWithBlock:^(BOOL succeeded, NSError * error) {
        if(!error)
        {
            NSLog(@" User registered!!");
            [self performSegueWithIdentifier:@"register" sender:self];
        }
        else
            NSLog(@"error registering user!");
    }];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
