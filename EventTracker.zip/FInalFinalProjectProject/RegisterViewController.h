//
//  RegisterViewController.h
//  IdentifyTheFlag!
//
//  Created by Apuroopa Santoshi Katralapalli on 12/8/15.
//  Copyright © 2015 Nagarjun Nama Balaji. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *emailField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UITextField *reEnterPasswordField;
@property NSString* CityName;

-(void) collectCity:(NSString*) CityName;

- (IBAction)registerAction:(id)sender;
- (IBAction)registeredButton:(id)sender;@end
