//
//  ViewController.h
//  Flags
//
//  Created by Robert Irwin on 9/22/15.
//  Copyright (c) 2015 Robert Irwin. All rights reserved.
//

@import UIKit;

@interface ViewController : UIViewController <UITextViewDelegate, UIPickerViewDataSource, UIPickerViewDelegate>

@property (weak, nonatomic) IBOutlet UIPickerView *countryPicker;
@property (weak, nonatomic) IBOutlet UIImageView *displayedFlag;

@end

