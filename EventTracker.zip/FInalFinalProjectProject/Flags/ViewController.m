//
//  ViewController.m
//  Flags
//
//  Created by Robert Irwin on 9/22/15.
//  Copyright (c) 2015 Robert Irwin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (strong,nonatomic,readonly) NSArray *country;
@property (strong,nonatomic,readonly) NSArray *flag;
@property (assign) NSInteger questionIndex;  // NSInteger typedef'd to primitive long type, can just assign value
@property (assign) NSInteger maxIndex;      // NSUInteger typedef'd to primitive unsigned long type
@property (assign) NSInteger displayedFlagIndex;  // index of flag to identify

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // must use ivar directly, as there is no setter for the assoc. property
    _country = @[ @"Ghana", @"China", @"India", @"Denmark", @"USA", @"Brazil", @"New Guinea"];
    // must use ivar directly, as there is no setter for the assoc. property
    _flag = @[@"Africa-Ghana.png", @"Asia-China.png", @"Asia-India.png", @"Europe-Denmark.png",
              @"North_America-USA.png", @"South_America-Brazil.png", @"Oceania-New_Guinea.png"];
    // Connect data
    self.countryPicker.dataSource = self;
    self.countryPicker.delegate = self;
    self.maxIndex = [_country count];
    self.displayedFlagIndex = arc4random() % self.maxIndex;
    [self.displayedFlag setImage:[UIImage imageNamed: _flag[self.displayedFlagIndex]]];
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self action:@selector(tapHandler:)];
    tapGR.numberOfTapsRequired = 1;           // set appropriate GR attributes
    self.displayedFlag.userInteractionEnabled = YES;
    [self.displayedFlag addGestureRecognizer:tapGR];  // add GR to view
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void) tapHandler: (UITapGestureRecognizer *) sender
{
    NSLog(@"in tapHandler");
    self.displayedFlagIndex = arc4random() % self.maxIndex;
    [self.displayedFlag setImage:[UIImage imageNamed: _flag[self.displayedFlagIndex]]];
}


// The number of columns of data
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _country.count;
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _country[row];
}


- (void)pickerView:(UIPickerView *)pickerView
      didSelectRow:(NSInteger)row
       inComponent:(NSInteger)component
{
    if ( row == self.displayedFlagIndex )
    {
    }
}

@end
